// src/lib/zhihu.ts
async function jsonFetch(url) {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) throw new Error(`zhihu fetch ${url} -> ${res.status}`);
  return await res.json();
}
async function fetchMe() {
  const data = await jsonFetch(
    "https://www.zhihu.com/api/v4/me?include=name,avatar_url,url_token"
  );
  return {
    id: String(data.url_token || data.id || ""),
    url_token: String(data.url_token || ""),
    name: String(data.name || ""),
    avatar_url: data.avatar_url || void 0
  };
}
function stripHtml(html) {
  return html.replace(/<style[\s\S]*?<\/style>/gi, "").replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\n{3,}/g, "\n\n").trim();
}
async function fetchAllMyAnswers(urlToken, onProgress) {
  const collected = [];
  let offset = 0;
  const limit = 20;
  let total = null;
  for (let i = 0; i < 100; i++) {
    const url = `https://www.zhihu.com/api/v4/members/${encodeURIComponent(urlToken)}/answers?offset=${offset}&limit=${limit}&include=data%5B*%5D.is_normal%2Cvoteup_count%2Ccontent%2Cexcerpt%2Cquestion.title%2Curl`;
    let payload;
    try {
      payload = await jsonFetch(url);
    } catch (e) {
      console.warn("[zsd] fetchAnswers failed at offset", offset, e);
      break;
    }
    const items = payload?.data || [];
    total = payload?.paging?.totals ?? total;
    for (const it of items) {
      const content = stripHtml(String(it.content || ""));
      if (!content) continue;
      collected.push({
        answer_id: String(it.id || it.answer_id || ""),
        author_id: String(it.author?.url_token || it.author?.id || ""),
        title: String(it.question?.title || ""),
        content,
        excerpt: stripHtml(String(it.excerpt || "")).slice(0, 240) || content.slice(0, 200),
        voteup_count: Number(it.voteup_count) || 0,
        url: it.url || (it.question?.id && it.id ? `https://www.zhihu.com/question/${it.question.id}/answer/${it.id}` : ""),
        kind: "answer"
      });
    }
    onProgress?.(collected.length, total);
    if (items.length === 0 || payload?.paging?.is_end) break;
    offset += limit;
  }
  return collected;
}
function parseAnswerElement(el) {
  const zop = el.getAttribute("data-zop");
  if (!zop) return null;
  let meta;
  try {
    meta = JSON.parse(zop);
  } catch {
    return null;
  }
  const answerId = String(meta.itemId || "");
  const authorId = String(meta.authorMemberHash || meta.authorId || "");
  if (!answerId) return null;
  const titleEl = el.querySelector(
    ".QuestionItem-title, .ContentItem-title, h2"
  );
  const contentEl = el.querySelector(
    ".RichContent-inner, .RichText, .content"
  );
  const voteEl = el.querySelector(
    ".VoteButton--up .Button-label, .VoteButton .Button-label, .VoteButton"
  );
  const linkEl = el.querySelector('a[href*="/answer/"]');
  const content = stripHtml(contentEl?.innerHTML || "");
  const voteText = (voteEl?.textContent || "").trim();
  const voteup_count = parseVote(voteText);
  return {
    answer_id: answerId,
    author_id: authorId,
    title: (titleEl?.textContent || "").trim(),
    content,
    excerpt: content.slice(0, 200),
    voteup_count,
    url: linkEl?.href || "",
    kind: "answer"
  };
}
function parseVote(s) {
  const m = s.match(/([\d.]+)\s*(万|w|k)?/i);
  if (!m) return 0;
  let n = parseFloat(m[1]);
  if (!isFinite(n)) return 0;
  const unit = (m[2] || "").toLowerCase();
  if (unit === "\u4E07" || unit === "w") n *= 1e4;
  else if (unit === "k") n *= 1e3;
  return Math.round(n);
}

// src/content.ts
var STATE = {
  me: null,
  selected: /* @__PURE__ */ new Map()
};
async function ensureMe() {
  if (STATE.me) return STATE.me;
  try {
    STATE.me = await fetchMe();
  } catch (e) {
    console.warn("[zsd] fetchMe failed", e);
  }
  if (STATE.me?.url_token) {
    try {
      const reply = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: "ensure_link", url_token: STATE.me.url_token },
          (r) => resolve(r)
        );
      });
      if (reply?.ok && reply.result?.linked) {
        console.log("[zsd] linked url_token to backend session:", reply.result.note);
      } else if (reply && !reply.ok) {
        console.warn("[zsd] link failed:", reply.error);
      }
    } catch (e) {
      console.warn("[zsd] ensure_link error", e);
    }
  }
  return STATE.me;
}
function isMyProfilePage() {
  const me = STATE.me;
  if (!me?.url_token) return false;
  const m = location.pathname.match(/^\/people\/([^/]+)/);
  if (!m) return false;
  return m[1] === me.url_token;
}
function ensureToolbar() {
  if (document.getElementById("zsd-toolbar")) return;
  if (!isMyProfilePage()) return;
  const bar = document.createElement("div");
  bar.id = "zsd-toolbar";
  bar.className = "zsd-toolbar";
  bar.innerHTML = `
    <div class="zsd-toolbar-inner">
      <div class="zsd-toolbar-title">
        <span class="zsd-toolbar-logo">\u{1F9EA}</span>
        \u77E5\u8BC6\u84B8\u998F\u9986
      </div>
      <div class="zsd-toolbar-status" id="zsd-status">\u70B9\u9009\u4E0B\u65B9\u56DE\u7B54\u6216\u4E00\u952E\u6279\u91CF\u6293\u53D6</div>
      <div class="zsd-toolbar-actions">
        <button id="zsd-btn-fetch-all" class="zsd-btn zsd-btn-primary">\u4E00\u952E\u6279\u91CF\u6293\u53D6\u6211\u7684\u5168\u90E8\u56DE\u7B54</button>
        <button id="zsd-btn-upload" class="zsd-btn">\u4E0A\u4F20\u5DF2\u9009 <span id="zsd-count">0</span> \u6761</button>
        <button id="zsd-btn-clear" class="zsd-btn zsd-btn-ghost">\u6E05\u7A7A</button>
      </div>
    </div>
  `;
  document.body.appendChild(bar);
  bar.querySelector("#zsd-btn-fetch-all").addEventListener("click", onBatchFetch);
  bar.querySelector("#zsd-btn-upload").addEventListener("click", onUploadSelected);
  bar.querySelector("#zsd-btn-clear").addEventListener("click", () => clearSelection());
}
function setStatus(text, kind = "info") {
  const el = document.getElementById("zsd-status");
  if (!el) return;
  el.textContent = text;
  el.dataset.kind = kind;
}
function updateCount() {
  const el = document.getElementById("zsd-count");
  if (el) el.textContent = String(STATE.selected.size);
}
function clearSelection(opts = {}) {
  STATE.selected.clear();
  document.querySelectorAll(".zsd-checkbox.zsd-checked").forEach((b) => {
    b.classList.remove("zsd-checked");
  });
  updateCount();
  if (!opts.silent) setStatus("\u5DF2\u6E05\u7A7A\u9009\u62E9");
}
function cardBelongsToMe(el, myUrlToken) {
  const anchors = el.querySelectorAll('a[href*="/people/"]');
  for (const a of Array.from(anchors)) {
    const href = a.getAttribute("href") || "";
    const m = href.match(/\/people\/([^/?#]+)/);
    if (m && m[1] === myUrlToken) return true;
  }
  return false;
}
function injectCheckboxes() {
  if (!isMyProfilePage()) return;
  const me = STATE.me;
  if (!me?.url_token) return;
  const items = document.querySelectorAll("[data-zop]");
  items.forEach((el) => {
    const marker = el.dataset.zsdInjected;
    if (marker === "1" || marker === "skip") return;
    const parsed = parseAnswerElement(el);
    if (!parsed) {
      ;
      el.dataset.zsdInjected = "skip";
      return;
    }
    if (!cardBelongsToMe(el, me.url_token)) {
      ;
      el.dataset.zsdInjected = "skip";
      return;
    }
    ;
    el.dataset.zsdInjected = "1";
    const checkbox = document.createElement("button");
    checkbox.className = "zsd-checkbox";
    checkbox.type = "button";
    checkbox.title = "\u52A0\u5165\u84B8\u998F";
    checkbox.innerHTML = '<span class="zsd-checkbox-tick">\u2713</span> \u52A0\u5165\u84B8\u998F';
    checkbox.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const me2 = STATE.me;
      if (!me2) {
        setStatus("\u672A\u8BC6\u522B\u5230\u767B\u5F55\u6001\uFF0C\u8BF7\u5148\u767B\u5F55\u77E5\u4E4E", "err");
        return;
      }
      const ans = { ...parsed, author_id: me2.id };
      if (STATE.selected.has(ans.answer_id)) {
        STATE.selected.delete(ans.answer_id);
        checkbox.classList.remove("zsd-checked");
      } else {
        STATE.selected.set(ans.answer_id, ans);
        checkbox.classList.add("zsd-checked");
      }
      updateCount();
    });
    const anchor = el.querySelector(".ContentItem-actions") || el.querySelector(".ContentItem-meta") || el;
    anchor.appendChild(checkbox);
  });
}
async function onBatchFetch() {
  const me = await ensureMe();
  if (!me?.url_token) {
    setStatus("\u672A\u8BC6\u522B\u5230\u77E5\u4E4E\u767B\u5F55\u6001\uFF0C\u8BF7\u5148\u767B\u5F55\u540E\u5237\u65B0", "err");
    return;
  }
  setStatus("\u6B63\u5728\u6279\u91CF\u6293\u53D6\u4F60\u7684\u56DE\u7B54\u2026");
  try {
    const all = await fetchAllMyAnswers(me.url_token, (cur, total) => {
      setStatus(`\u5DF2\u6293\u53D6 ${cur}${total ? ` / ${total}` : ""} \u6761\u2026`);
    });
    all.forEach((a) => {
      STATE.selected.set(a.answer_id, { ...a, author_id: me.id });
    });
    updateCount();
    setStatus(`\u6293\u53D6\u5B8C\u6210\uFF0C\u5171 ${all.length} \u6761\u3002\u70B9\u51FB\u300C\u4E0A\u4F20\u300D\u53D1\u9001\u5230\u84B8\u998F\u9986\u3002`, "ok");
  } catch (e) {
    setStatus(`\u6293\u53D6\u5931\u8D25\uFF1A${e?.message || e}`, "err");
  }
}
async function onUploadSelected() {
  const planned = STATE.selected.size;
  if (planned === 0) {
    setStatus("\u8FD8\u6CA1\u6709\u52FE\u9009\u4EFB\u4F55\u56DE\u7B54", "err");
    return;
  }
  setStatus(`\u6B63\u5728\u4E0A\u4F20 ${planned} \u6761\u2026`);
  const answers = [...STATE.selected.values()];
  const reply = await new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "upload", answers }, (r) => resolve(r));
  });
  if (!reply?.ok) {
    setStatus(`\u4E0A\u4F20\u5931\u8D25\uFF1A${reply?.error || "unknown"}`, "err");
    return;
  }
  const { accepted, rejected = [], total_for_user } = reply.result;
  const rejectedIds = new Set(rejected.map((r) => String(r.answer_id)));
  for (const id of [...STATE.selected.keys()]) {
    if (!rejectedIds.has(id)) STATE.selected.delete(id);
  }
  document.querySelectorAll(".zsd-checkbox.zsd-checked").forEach((b) => {
    const card = b.closest("[data-zop]");
    if (!card) return;
    let zop = {};
    try {
      zop = JSON.parse(card.getAttribute("data-zop") || "{}");
    } catch {
    }
    const id = String(zop.itemId || "");
    if (id && !STATE.selected.has(id)) b.classList.remove("zsd-checked");
  });
  updateCount();
  const head = accepted > 0 ? `\u2705 \u4E0A\u4F20\u6210\u529F ${accepted} \u6761` : "\u26A0\uFE0F \u6CA1\u6709\u4EFB\u4F55\u6761\u76EE\u5165\u5E93";
  const tail = rejected.length > 0 ? `\uFF1B\u88AB\u62D2 ${rejected.length} \u6761\uFF08${rejected.slice(0, 3).map((r) => r.reason).join("\uFF1B")}${rejected.length > 3 ? "\u2026" : ""}\uFF09` : "";
  const total = typeof total_for_user === "number" ? `\uFF1B\u5F53\u524D\u7D2F\u8BA1 ${total_for_user} \u6761` : "";
  setStatus(`${head}${tail}${total}\u3002\u53EF\u53BB\u84B8\u998F\u9986\u70B9\u300C\u6211\u81EA\u5DF1\u300D\u91CD\u65B0\u84B8\u998F\u3002`, accepted > 0 ? "ok" : "err");
}
async function init() {
  await ensureMe();
  ensureToolbar();
  injectCheckboxes();
}
var observer = new MutationObserver(() => {
  ensureToolbar();
  injectCheckboxes();
});
observer.observe(document.body, { childList: true, subtree: true });
var _pushState = history.pushState;
history.pushState = function(...args) {
  const r = _pushState.apply(this, args);
  window.dispatchEvent(new Event("zsd:locationchange"));
  return r;
};
window.addEventListener("popstate", () => window.dispatchEvent(new Event("zsd:locationchange")));
window.addEventListener("zsd:locationchange", () => {
  ensureToolbar();
  injectCheckboxes();
});
init();
