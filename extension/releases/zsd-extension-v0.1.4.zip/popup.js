// src/lib/storage.ts
var DEFAULT_API_BASE = "https://zhihusoul.cn";
async function getConfig() {
  const stored = await chrome.storage.local.get(["apiBase", "token", "linkedUrlToken"]);
  return {
    apiBase: stored.apiBase || DEFAULT_API_BASE,
    token: stored.token || "",
    linkedUrlToken: stored.linkedUrlToken || ""
  };
}
async function setConfig(patch) {
  const updates = {};
  if (typeof patch.apiBase === "string") updates.apiBase = patch.apiBase;
  if (typeof patch.token === "string") updates.token = patch.token;
  if (typeof patch.linkedUrlToken === "string") updates.linkedUrlToken = patch.linkedUrlToken;
  await chrome.storage.local.set(updates);
}

// src/popup.ts
var $ = (id) => document.getElementById(id);
function setStatus(text, kind = "info") {
  const el = $("status");
  el.textContent = text;
  el.dataset.kind = kind;
}
async function load() {
  const cfg = await getConfig();
  $("apiBaseShow").textContent = cfg.apiBase || "\uFF08\u672A\u914D\u7F6E\uFF09";
  const t = cfg.token;
  $("tokenShow").textContent = t ? `${t.slice(0, 16)}\u2026${t.slice(-8)}` : "\uFF08\u672A\u914D\u7F6E\uFF09";
  if (t) setStatus("Token \u5DF2\u914D\u7F6E\u3002\u53EF\u70B9\u300C\u6821\u9A8C\u767B\u5F55\u6001\u300D\u8BD5\u8BD5\u3002");
  else setStatus("\u6253\u5F00 zhihusoul.cn\uFF0C\u70B9\u300C\u4E00\u952E\u5199\u5165\u63D2\u4EF6\u300D\u5373\u53EF\u81EA\u52A8\u914D\u7F6E\u3002");
}
$("openApp").addEventListener("click", async (e) => {
  e.preventDefault();
  const cfg = await getConfig();
  chrome.tabs.create({ url: cfg.apiBase || "https://zhihusoul.cn" });
});
$("open-app").addEventListener("click", async () => {
  const cfg = await getConfig();
  chrome.tabs.create({ url: cfg.apiBase || "https://zhihusoul.cn" });
});
$("save").addEventListener("click", async () => {
  const token = ($("token").value || "").trim();
  if (!token) {
    setStatus("\u8BF7\u7C98\u8D34 Token", "err");
    return;
  }
  await setConfig({ token, linkedUrlToken: "" });
  $("token").value = "";
  await load();
  setStatus("Token \u5DF2\u624B\u52A8\u4FDD\u5B58\u3002", "ok");
});
$("ping").addEventListener("click", () => {
  setStatus("\u6821\u9A8C\u4E2D\u2026");
  chrome.runtime.sendMessage({ type: "ping_backend" }, (r) => {
    if (!r?.ok) {
      setStatus(`\u6821\u9A8C\u5931\u8D25\uFF1A${r?.error || "unknown"}`, "err");
      return;
    }
    if (!r.user) {
      setStatus("Token \u5DF2\u6536\u5230\uFF0C\u4F46\u540E\u7AEF\u672A\u8BC6\u522B\u767B\u5F55\u6001\u3002\u8BF7\u56DE\u5230 zhihusoul.cn \u91CD\u65B0\u300C\u4E00\u952E\u5199\u5165\u63D2\u4EF6\u300D\u3002", "err");
      return;
    }
    const u = r.user;
    const uc = typeof u.upload_count === "number" ? `\uFF0C\u7D2F\u8BA1 ${u.upload_count} \u6761\u4E0A\u4F20` : "";
    const linked = u.linked_url_token ? `
\u5DF2\u7ED1\u5B9A url_token\uFF1A${u.linked_url_token}` : "\n\u672A\u7ED1\u5B9A url_token\uFF08\u53BB\u81EA\u5DF1\u7684\u77E5\u4E4E\u4E3B\u9875\u6253\u5F00\u4E00\u6B21\u5373\u53EF\u81EA\u52A8\u7ED1\u5B9A\uFF09";
    setStatus(`\u767B\u5F55\u4E3A ${u.name}\uFF08OAuth id=${u.id}\uFF09${uc}${linked}`, "ok");
  });
});
load();
