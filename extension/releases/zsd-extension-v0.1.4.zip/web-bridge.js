// src/lib/storage.ts
async function setConfig(patch) {
  const updates = {};
  if (typeof patch.apiBase === "string") updates.apiBase = patch.apiBase;
  if (typeof patch.token === "string") updates.token = patch.token;
  if (typeof patch.linkedUrlToken === "string") updates.linkedUrlToken = patch.linkedUrlToken;
  await chrome.storage.local.set(updates);
}

// src/web-bridge.ts
var ALLOWED_ORIGINS = /* @__PURE__ */ new Set([
  "https://zhihusoul.cn",
  "https://www.zhihusoul.cn",
  "http://localhost:3000"
]);
function post(payload) {
  try {
    window.postMessage(payload, window.location.origin);
  } catch (e) {
    console.warn("[zsd-bridge] postMessage failed", e);
  }
}
window.addEventListener("message", async (ev) => {
  if (!ALLOWED_ORIGINS.has(ev.origin)) return;
  const data = ev.data;
  if (!data || typeof data !== "object") return;
  if (data.type === "zsd:ping") {
    post({ type: "zsd:pong", version: chrome.runtime.getManifest().version });
    return;
  }
  if (data.type === "zsd:install-token") {
    const token = String(data.token || "").trim();
    const apiBase = String(data.apiBase || ev.origin || "").replace(/\/$/, "");
    if (!token) {
      post({ type: "zsd:install-token-ack", ok: false, error: "\u7A7A token" });
      return;
    }
    try {
      await setConfig({ token, apiBase, linkedUrlToken: "" });
      post({
        type: "zsd:install-token-ack",
        ok: true,
        apiBase,
        version: chrome.runtime.getManifest().version
      });
    } catch (e) {
      post({ type: "zsd:install-token-ack", ok: false, error: String(e?.message || e) });
    }
  }
});
post({ type: "zsd:installed", version: chrome.runtime.getManifest().version });
