// src/lib/zhihu.ts
async function jsonFetch(url) {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) throw new Error(`zhihu fetch ${url} -> ${res.status}`);
  return await res.json();
}
async function fetchMe() {
  const data = await jsonFetch(
    "https://www.zhihu.com/api/v4/me?include=name,avatar_url,url_token"
  );
  return {
    id: String(data.url_token || data.id || ""),
    url_token: String(data.url_token || ""),
    name: String(data.name || ""),
    avatar_url: data.avatar_url || void 0
  };
}
function stripHtml(html) {
  return html.replace(/<style[\s\S]*?<\/style>/gi, "").replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\n{3,}/g, "\n\n").trim();
}
async function fetchFullAnswerContent(answerId) {
  try {
    const data = await jsonFetch(
      `https://www.zhihu.com/api/v4/answers/${answerId}?include=content`
    );
    const raw = data.content || data.excerpt || "";
    return raw ? stripHtml(raw) : "";
  } catch {
    return "";
  }
}
function parseAnswerElement(el) {
  const zop = el.getAttribute("data-zop");
  if (!zop) return null;
  let meta;
  try {
    meta = JSON.parse(zop);
  } catch {
    return null;
  }
  const answerId = String(meta.itemId || "");
  const authorId = String(meta.authorMemberHash || meta.authorId || "");
  if (!answerId) return null;
  const titleEl = el.querySelector(
    ".QuestionItem-title, .ContentItem-title, h2"
  );
  const contentEl = el.querySelector(
    ".RichContent-inner, .RichText, .content"
  );
  const voteEl = el.querySelector(
    ".VoteButton--up .Button-label, .VoteButton .Button-label, .VoteButton"
  );
  const linkEl = el.querySelector('a[href*="/answer/"]');
  const content = stripHtml(contentEl?.innerHTML || "");
  const voteText = (voteEl?.textContent || "").trim();
  const voteup_count = parseVote(voteText);
  return {
    answer_id: answerId,
    author_id: authorId,
    title: (titleEl?.textContent || "").trim(),
    content,
    excerpt: content.slice(0, 200),
    voteup_count,
    url: linkEl?.href || "",
    kind: "answer"
  };
}
function parseVote(s) {
  const m = s.match(/([\d.]+)\s*(万|w|k)?/i);
  if (!m) return 0;
  let n = parseFloat(m[1]);
  if (!isFinite(n)) return 0;
  const unit = (m[2] || "").toLowerCase();
  if (unit === "\u4E07" || unit === "w") n *= 1e4;
  else if (unit === "k") n *= 1e3;
  return Math.round(n);
}
function parseArticleElement() {
  const m = location.pathname.match(/^\/p\/(\d+)/);
  if (!m) return null;
  const articleId = m[1];
  const titleEl = document.querySelector(
    ".Post-Title, header h1, h1.Post-Title"
  );
  const contentEl = document.querySelector(
    ".Post-RichText, .Post-content .RichText, article .RichText, .RichText"
  );
  if (!contentEl) return null;
  const content = stripHtml(contentEl.innerHTML || "");
  if (!content) return null;
  const voteEl = document.querySelector(
    ".Post-content .VoteButton--up, .VoteButton--up, .VoteButton"
  );
  return {
    answer_id: articleId,
    author_id: "",
    title: (titleEl?.textContent || "").trim(),
    content,
    excerpt: content.slice(0, 300),
    voteup_count: parseVote((voteEl?.textContent || "").trim()),
    url: `https://zhuanlan.zhihu.com/p/${articleId}`,
    kind: "article"
  };
}
function articleAuthorToken() {
  const scope = document.querySelector(".Post-Header, .Post-Author, .PostIndex-author, .Post-Main header") || document;
  const a = scope.querySelector('.AuthorInfo a[href*="/people/"]');
  if (!a) return null;
  const m = (a.getAttribute("href") || "").match(/\/people\/([^/?#]+)/);
  return m ? m[1] : null;
}

// src/content.ts
var MAX = 10;
var STATE = {
  me: null,
  selected: /* @__PURE__ */ new Map(),
  // 后端已上传（已入库）的条数，作为「还可选择 x 条」的额度基准
  uploadCount: 0,
  uploadCountLoaded: false
};
async function ensureMe() {
  if (STATE.me) return STATE.me;
  try {
    STATE.me = await fetchMe();
  } catch (e) {
    console.warn("[zsd] fetchMe failed", e);
  }
  if (STATE.me?.url_token) {
    try {
      const reply = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: "ensure_link", url_token: STATE.me.url_token },
          (r) => resolve(r)
        );
      });
      if (reply?.ok && reply.result?.linked) {
        console.log("[zsd] linked url_token to backend session:", reply.result.note);
      } else if (reply && !reply.ok) {
        console.warn("[zsd] link failed:", reply.error);
      }
    } catch (e) {
      console.warn("[zsd] ensure_link error", e);
    }
  }
  return STATE.me;
}
async function ensureUploadCount() {
  if (STATE.uploadCountLoaded) return;
  try {
    const reply = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "ping_backend" }, (r) => resolve(r));
    });
    if (reply?.ok && reply.user && typeof reply.user.upload_count === "number") {
      STATE.uploadCount = reply.user.upload_count;
      STATE.uploadCountLoaded = true;
    }
  } catch (e) {
    console.warn("[zsd] ensureUploadCount failed", e);
  }
}
function isAnswerDetailPage() {
  if (location.hostname !== "www.zhihu.com") return false;
  return /^\/question\/\d+\/answer\/\d+/.test(location.pathname) || /^\/answer\/\d+/.test(location.pathname);
}
function isArticlePage() {
  if (location.hostname !== "zhuanlan.zhihu.com" && location.hostname !== "www.zhihu.com") {
    return false;
  }
  return /^\/p\/\d+/.test(location.pathname);
}
function isInjectablePage() {
  return isAnswerDetailPage() || isArticlePage();
}
function ensureToolbar() {
  if (!isInjectablePage()) return;
  if (document.getElementById("zsd-toolbar")) {
    refreshStatus();
    return;
  }
  const bar = document.createElement("div");
  bar.id = "zsd-toolbar";
  bar.className = "zsd-toolbar";
  bar.innerHTML = `
    <div class="zsd-toolbar-inner">
      <div class="zsd-toolbar-title">
        <span class="zsd-toolbar-logo">\u{1F9EA}</span>
        \u77E5\u8BC6\u84B8\u998F\u9986
      </div>
      <div class="zsd-toolbar-status" id="zsd-status">\u52FE\u9009\u4F60\u60F3\u84B8\u998F\u7684\u56DE\u7B54 / \u6587\u7AE0</div>
      <div class="zsd-toolbar-actions">
        <button id="zsd-btn-upload" class="zsd-btn zsd-btn-primary">\u4E0A\u4F20\u5DF2\u9009 <span id="zsd-count">0</span> \u6761</button>
        <button id="zsd-btn-clear" class="zsd-btn zsd-btn-ghost">\u6E05\u7A7A</button>
      </div>
    </div>
  `;
  document.body.appendChild(bar);
  bar.querySelector("#zsd-btn-upload").addEventListener("click", onUploadSelected);
  bar.querySelector("#zsd-btn-clear").addEventListener("click", () => clearSelection());
  refreshStatus();
}
function showToast(msg) {
  const existing = document.getElementById("zsd-toast");
  if (existing) existing.remove();
  const toast = document.createElement("div");
  toast.id = "zsd-toast";
  toast.className = "zsd-toast";
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3e3);
}
function setStatus(text, kind = "info") {
  const el = document.getElementById("zsd-status");
  if (!el) return;
  el.textContent = text;
  el.dataset.kind = kind;
}
function updateCount() {
  const el = document.getElementById("zsd-count");
  if (el) el.textContent = String(STATE.selected.size);
}
function remaining() {
  return Math.max(0, MAX - STATE.uploadCount - STATE.selected.size);
}
function limitMessage() {
  if (STATE.uploadCount >= MAX) {
    return `\u84B8\u998F\u9986\u5DF2\u6EE1 ${MAX} \u6761\uFF0C\u8BF7\u5148\u5230\u84B8\u998F\u9986\u300C\u7BA1\u7406\u6211\u7684\u84B8\u998F\u300D\u5220\u9664\u90E8\u5206\u5185\u5BB9\u540E\u518D\u52A0\u3002`;
  }
  return `\u6700\u591A\u84B8\u998F ${MAX} \u6761\uFF1A\u4F60\u5DF2\u4E0A\u4F20 ${STATE.uploadCount} \u6761\u3001\u672C\u6B21\u5DF2\u9009 ${STATE.selected.size} \u6761\uFF0C\u65E0\u6CD5\u518D\u52A0\u3002`;
}
function refreshStatus() {
  updateCount();
  if (STATE.uploadCount >= MAX) {
    setStatus(`\u5DF2\u6EE1 ${MAX} \u6761\uFF1A\u84B8\u998F\u9986\u6BCF\u4EBA\u6700\u591A\u4FDD\u7559 ${MAX} \u6761\uFF0C\u53BB\u84B8\u998F\u9986\u5220\u6389\u4E00\u4E9B\u518D\u6765\u5427\u3002`, "err");
    return;
  }
  const r = remaining();
  const parts = [`\u8FD8\u53EF\u9009\u62E9 ${r} \u6761`];
  if (STATE.uploadCountLoaded) parts.push(`\u5DF2\u4E0A\u4F20 ${STATE.uploadCount} \u6761`);
  if (STATE.selected.size > 0) parts.push(`\u672C\u6B21\u5DF2\u9009 ${STATE.selected.size} \u6761`);
  setStatus(parts.join(" \xB7 "), r > 0 ? "info" : "err");
}
function clearSelection(opts = {}) {
  STATE.selected.clear();
  document.querySelectorAll(".zsd-checkbox.zsd-checked").forEach((b) => {
    b.classList.remove("zsd-checked");
  });
  if (opts.silent) {
    updateCount();
  } else {
    refreshStatus();
  }
}
function cardBelongsToMe(el, myUrlToken) {
  const anchors = el.querySelectorAll('a[href*="/people/"]');
  for (const a of Array.from(anchors)) {
    const href = a.getAttribute("href") || "";
    const m = href.match(/\/people\/([^/?#]+)/);
    if (m && m[1] === myUrlToken) return true;
  }
  return false;
}
function createCheckbox(parsed) {
  const checkbox = document.createElement("button");
  checkbox.className = "zsd-checkbox";
  checkbox.type = "button";
  checkbox.title = "\u52A0\u5165\u84B8\u998F";
  checkbox.innerHTML = '<span class="zsd-checkbox-tick">\u2713</span> \u52A0\u5165\u84B8\u998F';
  if (STATE.selected.has(parsed.answer_id)) checkbox.classList.add("zsd-checked");
  checkbox.addEventListener("click", async (e) => {
    e.preventDefault();
    e.stopPropagation();
    const me = STATE.me;
    if (!me) {
      setStatus("\u672A\u8BC6\u522B\u5230\u767B\u5F55\u6001\uFF0C\u8BF7\u5148\u767B\u5F55\u77E5\u4E4E", "err");
      return;
    }
    const ans = { ...parsed, author_id: me.id };
    if (STATE.selected.has(ans.answer_id)) {
      STATE.selected.delete(ans.answer_id);
      checkbox.classList.remove("zsd-checked");
      refreshStatus();
      return;
    }
    if (remaining() <= 0) {
      showToast(limitMessage());
      return;
    }
    checkbox.classList.add("zsd-checked");
    STATE.selected.set(ans.answer_id, ans);
    refreshStatus();
    if (ans.kind === "answer") {
      setStatus("\u6B63\u5728\u83B7\u53D6\u5168\u6587\u2026");
      try {
        const fullContent = await fetchFullAnswerContent(ans.answer_id);
        if (fullContent && fullContent.length > ans.content.length) {
          ans.content = fullContent;
          ans.excerpt = fullContent.slice(0, 300);
          STATE.selected.set(ans.answer_id, ans);
        }
      } catch {
      }
      refreshStatus();
    }
  });
  return checkbox;
}
function injectAnswerCheckboxes() {
  if (!isAnswerDetailPage()) return;
  const me = STATE.me;
  if (!me?.url_token) return;
  const items = document.querySelectorAll("[data-zop]");
  items.forEach((el) => {
    const marker = el.dataset.zsdInjected;
    if (marker === "1" || marker === "skip") return;
    const parsed = parseAnswerElement(el);
    if (!parsed) {
      ;
      el.dataset.zsdInjected = "skip";
      return;
    }
    if (!cardBelongsToMe(el, me.url_token)) {
      ;
      el.dataset.zsdInjected = "skip";
      return;
    }
    ;
    el.dataset.zsdInjected = "1";
    const checkbox = createCheckbox(parsed);
    const anchor = el.querySelector(".ContentItem-actions") || el.querySelector(".ContentItem-meta") || el;
    anchor.appendChild(checkbox);
  });
}
function injectArticleButton() {
  if (!isArticlePage()) return;
  const me = STATE.me;
  if (!me?.url_token) return;
  if (document.getElementById("zsd-article-checkbox")) return;
  const author = articleAuthorToken();
  if (!author) return;
  if (author !== me.url_token) return;
  const parsed = parseArticleElement();
  if (!parsed) return;
  const checkbox = createCheckbox(parsed);
  checkbox.id = "zsd-article-checkbox";
  checkbox.classList.add("zsd-checkbox-article");
  const anchor = document.querySelector(".Post-Header") || document.querySelector(".Post-Title")?.parentElement || document.querySelector(".ContentItem-actions") || document.body;
  anchor.appendChild(checkbox);
}
async function onUploadSelected() {
  const planned = STATE.selected.size;
  if (planned === 0) {
    setStatus("\u8FD8\u6CA1\u6709\u52FE\u9009\u4EFB\u4F55\u56DE\u7B54 / \u6587\u7AE0", "err");
    return;
  }
  setStatus(`\u6B63\u5728\u4E0A\u4F20 ${planned} \u6761\u2026`);
  const answers = [...STATE.selected.values()];
  const reply = await new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "upload", answers }, (r) => resolve(r));
  });
  if (!reply?.ok) {
    setStatus(`\u4E0A\u4F20\u5931\u8D25\uFF1A${reply?.error || "unknown"}`, "err");
    return;
  }
  const { accepted, rejected = [], total_for_user } = reply.result;
  const rejectedIds = new Set(rejected.map((r) => String(r.answer_id)));
  for (const id of [...STATE.selected.keys()]) {
    if (!rejectedIds.has(id)) STATE.selected.delete(id);
  }
  document.querySelectorAll(".zsd-checkbox.zsd-checked").forEach((b) => {
    if (b.id === "zsd-article-checkbox") {
      const m = location.pathname.match(/^\/p\/(\d+)/);
      const id2 = m ? m[1] : "";
      if (id2 && !STATE.selected.has(id2)) b.classList.remove("zsd-checked");
      return;
    }
    const card = b.closest("[data-zop]");
    if (!card) return;
    let zop = {};
    try {
      zop = JSON.parse(card.getAttribute("data-zop") || "{}");
    } catch {
    }
    const id = String(zop.itemId || "");
    if (id && !STATE.selected.has(id)) b.classList.remove("zsd-checked");
  });
  if (typeof total_for_user === "number") {
    STATE.uploadCount = total_for_user;
    STATE.uploadCountLoaded = true;
  }
  updateCount();
  const head = accepted > 0 ? `\u2705 \u4E0A\u4F20\u6210\u529F ${accepted} \u6761` : "\u26A0\uFE0F \u6CA1\u6709\u4EFB\u4F55\u6761\u76EE\u5165\u5E93";
  const tail = rejected.length > 0 ? `\uFF1B\u88AB\u62D2 ${rejected.length} \u6761\uFF08${rejected.slice(0, 3).map((r) => r.reason).join("\uFF1B")}${rejected.length > 3 ? "\u2026" : ""}\uFF09` : "";
  const total = typeof total_for_user === "number" ? STATE.uploadCount >= MAX ? `\uFF1B\u5DF2\u6EE1 ${MAX} \u6761` : `\uFF1B\u5F53\u524D\u7D2F\u8BA1 ${STATE.uploadCount} \u6761\uFF0C\u8FD8\u53EF\u9009\u62E9 ${remaining()} \u6761` : "";
  setStatus(`${head}${tail}${total}\u3002\u53EF\u53BB\u84B8\u998F\u9986\u70B9\u300C\u7BA1\u7406\u6211\u7684\u84B8\u998F\u300D\u91CD\u65B0\u84B8\u998F\u3002`, accepted > 0 ? "ok" : "err");
}
function tick() {
  if (!isInjectablePage()) {
    document.getElementById("zsd-toolbar")?.remove();
    return;
  }
  ensureToolbar();
  injectAnswerCheckboxes();
  injectArticleButton();
}
async function init() {
  await ensureMe();
  if (!isInjectablePage()) return;
  await ensureUploadCount();
  tick();
}
var observer = new MutationObserver(() => {
  tick();
});
observer.observe(document.body, { childList: true, subtree: true });
var _pushState = history.pushState;
history.pushState = function(...args) {
  const r = _pushState.apply(this, args);
  window.dispatchEvent(new Event("zsd:locationchange"));
  return r;
};
window.addEventListener("popstate", () => window.dispatchEvent(new Event("zsd:locationchange")));
window.addEventListener("zsd:locationchange", () => {
  document.getElementById("zsd-article-checkbox")?.remove();
  void ensureUploadCount();
  tick();
});
init();
