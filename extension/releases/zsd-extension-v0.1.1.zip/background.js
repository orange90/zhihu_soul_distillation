// src/lib/storage.ts
var DEFAULT_API_BASE = "http://localhost:3000";
async function getConfig() {
  const stored = await chrome.storage.local.get(["apiBase", "token"]);
  return {
    apiBase: stored.apiBase || DEFAULT_API_BASE,
    token: stored.token || ""
  };
}

// src/lib/api.ts
async function authHeaders() {
  const { token } = await getConfig();
  if (!token) throw new Error("\u672A\u914D\u7F6E Token\uFF0C\u8BF7\u5148\u5230 popup \u7C98\u8D34");
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
    "X-Plugin-Version": chrome.runtime.getManifest().version
  };
}
async function pingMe() {
  const { apiBase } = await getConfig();
  const headers = await authHeaders();
  const url = `${apiBase}/api/auth/me`;
  let res;
  try {
    res = await fetch(url, { headers, credentials: "include" });
  } catch (e) {
    throw new Error(`\u65E0\u6CD5\u8FDE\u63A5\u5230 ${url}\uFF08${e?.message || e}\uFF09`);
  }
  if (!res.ok) throw new Error(`/api/auth/me ${res.status}`);
  const json = await res.json();
  return json.user;
}
async function uploadAnswers(answers) {
  const { apiBase } = await getConfig();
  const headers = await authHeaders();
  const url = `${apiBase}/api/upload-answers`;
  let res;
  try {
    res = await fetch(url, {
      method: "POST",
      headers,
      credentials: "include",
      body: JSON.stringify({ answers })
    });
  } catch (e) {
    throw new Error(
      `\u65E0\u6CD5\u8FDE\u63A5\u5230 ${url}\uFF08${e?.message || e}\uFF09\u3002\u8BF7\u68C0\u67E5\uFF1A1) popup \u91CC\u7684\u540E\u7AEF\u5730\u5740\u662F\u5426\u586B\u5BF9\uFF1B2) \u540E\u7AEF\u670D\u52A1\u662F\u5426\u5DF2\u542F\u52A8\uFF1B3) \u8BE5\u540E\u7AEF\u662F\u5426\u90E8\u7F72\u4E86 /api/upload-answers \u63A5\u53E3\uFF1B4) chrome://extensions \u627E\u5230\u672C\u6269\u5C55\uFF0C\u70B9 "service worker" \u770B Network \u6807\u7B7E\u67E5\u770B\u5B9E\u9645\u9519\u8BEF\u3002`
    );
  }
  const text = await res.text();
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
  }
  if (!res.ok) {
    throw new Error(json.error || `upload failed: ${res.status} ${text.slice(0, 200)}`);
  }
  return json;
}

// src/background.ts
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  ;
  (async () => {
    try {
      if (msg.type === "upload") {
        const r = await uploadAnswers(msg.answers);
        sendResponse({ ok: true, result: r });
        return;
      }
      if (msg.type === "ping_backend") {
        const user = await pingMe();
        sendResponse({ ok: true, user });
        return;
      }
      sendResponse({ ok: false, error: "unknown message type" });
    } catch (e) {
      sendResponse({ ok: false, error: String(e?.message || e) });
    }
  })();
  return true;
});
