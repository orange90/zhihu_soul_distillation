// src/lib/storage.ts
var DEFAULT_API_BASE = "http://localhost:3000";
async function getConfig() {
  const stored = await chrome.storage.local.get(["apiBase", "token", "linkedUrlToken"]);
  return {
    apiBase: stored.apiBase || DEFAULT_API_BASE,
    token: stored.token || "",
    linkedUrlToken: stored.linkedUrlToken || ""
  };
}
async function setConfig(patch) {
  const updates = {};
  if (typeof patch.apiBase === "string") updates.apiBase = patch.apiBase;
  if (typeof patch.token === "string") updates.token = patch.token;
  if (typeof patch.linkedUrlToken === "string") updates.linkedUrlToken = patch.linkedUrlToken;
  await chrome.storage.local.set(updates);
}

// src/popup.ts
var $ = (id) => document.getElementById(id);
function setStatus(text, kind = "info") {
  const el = $("status");
  el.textContent = text;
  el.dataset.kind = kind;
}
async function load() {
  const cfg = await getConfig();
  $("apiBase").value = cfg.apiBase;
  $("token").value = cfg.token;
  if (cfg.token) setStatus("\u5DF2\u914D\u7F6E Token\u3002\u70B9\u51FB\u300C\u6821\u9A8C\u767B\u5F55\u6001\u300D\u8BD5\u8BD5\u3002");
  else setStatus("\u8BF7\u5148\u5728\u84B8\u998F\u9986\u9996\u9875\u70B9\u300C\u83B7\u53D6\u63D2\u4EF6 Token\u300D\u5E76\u7C98\u8D34\u5230\u4E0A\u65B9\u3002");
}
function normalizeApiBase(raw) {
  let v = raw.trim().replace(/\/$/, "");
  if (!v) return { value: "", note: "" };
  const m = /^http:\/\/([^/]+)(.*)$/.exec(v);
  if (m && !/^(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?$/.test(m[1])) {
    v = `https://${m[1]}${m[2]}`;
    return { value: v, note: "\u5DF2\u81EA\u52A8\u6539\u4E3A https://\uFF08http\u2192https \u91CD\u5B9A\u5411\u4F1A\u8BA9 CORS preflight \u5931\u8D25\uFF09" };
  }
  return { value: v, note: "" };
}
$("save").addEventListener("click", async () => {
  const { value: apiBase, note } = normalizeApiBase($("apiBase").value || "");
  const token = ($("token").value || "").trim();
  if (!apiBase) {
    setStatus("\u8BF7\u586B\u5199\u540E\u7AEF\u5730\u5740", "err");
    return;
  }
  if (!token) {
    setStatus("\u8BF7\u7C98\u8D34 Token", "err");
    return;
  }
  ;
  $("apiBase").value = apiBase;
  await setConfig({ apiBase, token });
  setStatus(`\u5DF2\u4FDD\u5B58${note ? "\n" + note : ""}`, "ok");
});
$("ping").addEventListener("click", () => {
  setStatus("\u6821\u9A8C\u4E2D\u2026");
  chrome.runtime.sendMessage({ type: "ping_backend" }, (r) => {
    if (!r?.ok) {
      setStatus(`\u6821\u9A8C\u5931\u8D25\uFF1A${r?.error || "unknown"}`, "err");
      return;
    }
    if (!r.user) {
      setStatus("Token \u5DF2\u6536\u5230\uFF0C\u4F46\u540E\u7AEF\u672A\u8BC6\u522B\u767B\u5F55\u6001\u3002\u8BF7\u53BB\u84B8\u998F\u9986\u91CD\u65B0\u767B\u5F55\u540E\u518D\u53D6\u4E00\u6B21 Token\u3002", "err");
      return;
    }
    const u = r.user;
    const uc = typeof u.upload_count === "number" ? `\uFF0C\u7D2F\u8BA1 ${u.upload_count} \u6761\u4E0A\u4F20` : "";
    const linked = u.linked_url_token ? `
\u5DF2\u7ED1\u5B9A url_token\uFF1A${u.linked_url_token}` : "\n\u672A\u7ED1\u5B9A url_token\uFF08\u53BB\u81EA\u5DF1\u7684\u77E5\u4E4E\u4E3B\u9875\u6253\u5F00\u4E00\u6B21\u5373\u53EF\u81EA\u52A8\u7ED1\u5B9A\uFF09";
    setStatus(`\u767B\u5F55\u4E3A ${u.name}\uFF08OAuth id=${u.id}\uFF09${uc}${linked}`, "ok");
  });
});
$("open-app").addEventListener("click", async () => {
  const cfg = await getConfig();
  chrome.tabs.create({ url: cfg.apiBase || "http://localhost:3000" });
});
load();
