// src/lib/storage.ts
var DEFAULT_API_BASE = "http://localhost:3000";
async function getConfig() {
  const stored = await chrome.storage.local.get(["apiBase", "token"]);
  return {
    apiBase: stored.apiBase || DEFAULT_API_BASE,
    token: stored.token || ""
  };
}

// src/lib/api.ts
async function authHeaders() {
  const { token } = await getConfig();
  if (!token) throw new Error("\u672A\u914D\u7F6E Token\uFF0C\u8BF7\u5148\u5230 popup \u7C98\u8D34");
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
    "X-Plugin-Version": chrome.runtime.getManifest().version
  };
}
async function pingMe() {
  const { apiBase } = await getConfig();
  const headers = await authHeaders();
  const res = await fetch(`${apiBase}/api/auth/me`, { headers, credentials: "include" });
  if (!res.ok) throw new Error(`/api/auth/me ${res.status}`);
  const json = await res.json();
  return json.user;
}
async function uploadAnswers(answers) {
  const { apiBase } = await getConfig();
  const headers = await authHeaders();
  const res = await fetch(`${apiBase}/api/upload-answers`, {
    method: "POST",
    headers,
    credentials: "include",
    body: JSON.stringify({ answers })
  });
  const text = await res.text();
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
  }
  if (!res.ok) {
    throw new Error(json.error || `upload failed: ${res.status} ${text}`);
  }
  return json;
}

// src/background.ts
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  ;
  (async () => {
    try {
      if (msg.type === "upload") {
        const r = await uploadAnswers(msg.answers);
        sendResponse({ ok: true, result: r });
        return;
      }
      if (msg.type === "ping_backend") {
        const user = await pingMe();
        sendResponse({ ok: true, user });
        return;
      }
      sendResponse({ ok: false, error: "unknown message type" });
    } catch (e) {
      sendResponse({ ok: false, error: String(e?.message || e) });
    }
  })();
  return true;
});
