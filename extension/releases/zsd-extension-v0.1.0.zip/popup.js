// src/lib/storage.ts
var DEFAULT_API_BASE = "http://localhost:3000";
async function getConfig() {
  const stored = await chrome.storage.local.get(["apiBase", "token"]);
  return {
    apiBase: stored.apiBase || DEFAULT_API_BASE,
    token: stored.token || ""
  };
}
async function setConfig(patch) {
  const updates = {};
  if (typeof patch.apiBase === "string") updates.apiBase = patch.apiBase;
  if (typeof patch.token === "string") updates.token = patch.token;
  await chrome.storage.local.set(updates);
}

// src/popup.ts
var $ = (id) => document.getElementById(id);
function setStatus(text, kind = "info") {
  const el = $("status");
  el.textContent = text;
  el.dataset.kind = kind;
}
async function load() {
  const cfg = await getConfig();
  $("apiBase").value = cfg.apiBase;
  $("token").value = cfg.token;
  if (cfg.token) setStatus("\u5DF2\u914D\u7F6E Token\u3002\u70B9\u51FB\u300C\u6821\u9A8C\u767B\u5F55\u6001\u300D\u8BD5\u8BD5\u3002");
  else setStatus("\u8BF7\u5148\u5728\u84B8\u998F\u9986\u9996\u9875\u70B9\u300C\u83B7\u53D6\u63D2\u4EF6 Token\u300D\u5E76\u7C98\u8D34\u5230\u4E0A\u65B9\u3002");
}
$("save").addEventListener("click", async () => {
  const apiBase = ($("apiBase").value || "").trim().replace(/\/$/, "");
  const token = ($("token").value || "").trim();
  if (!apiBase) {
    setStatus("\u8BF7\u586B\u5199\u540E\u7AEF\u5730\u5740", "err");
    return;
  }
  if (!token) {
    setStatus("\u8BF7\u7C98\u8D34 Token", "err");
    return;
  }
  await setConfig({ apiBase, token });
  setStatus("\u5DF2\u4FDD\u5B58\u3002", "ok");
});
$("ping").addEventListener("click", () => {
  setStatus("\u6821\u9A8C\u4E2D\u2026");
  chrome.runtime.sendMessage({ type: "ping_backend" }, (r) => {
    if (!r?.ok) {
      setStatus(`\u6821\u9A8C\u5931\u8D25\uFF1A${r?.error || "unknown"}`, "err");
      return;
    }
    if (!r.user) {
      setStatus("Token \u5DF2\u6536\u5230\uFF0C\u4F46\u540E\u7AEF\u672A\u8BC6\u522B\u767B\u5F55\u6001\u3002\u8BF7\u53BB\u84B8\u998F\u9986\u91CD\u65B0\u767B\u5F55\u540E\u518D\u53D6\u4E00\u6B21 Token\u3002", "err");
      return;
    }
    const uc = typeof r.user.upload_count === "number" ? `\uFF0C\u7D2F\u8BA1 ${r.user.upload_count} \u6761\u4E0A\u4F20` : "";
    setStatus(`\u767B\u5F55\u4E3A ${r.user.name}\uFF08id=${r.user.id}\uFF09${uc}`, "ok");
  });
});
$("open-app").addEventListener("click", async () => {
  const cfg = await getConfig();
  chrome.tabs.create({ url: cfg.apiBase || "http://localhost:3000" });
});
load();
